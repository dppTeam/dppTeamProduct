//
//  PerformanceVC.m
//  HaiBaoApp
//
//  Created by ios on 17/4/10.
//  Copyright © 2017年 ervin. All rights reserved.
//
//团队业绩
#import "PerformanceVC.h"
#import "HCGDatePickerAppearance.h"

@interface PerformanceVC ()

@end

@implementation PerformanceVC
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.

    [self navBarTap];
    [self createDataSource];

}
-(void)createDataSource
{
  
    NSDate *date = [NSDate date];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    [formatter setTimeStyle:NSDateFormatterShortStyle];
    [formatter setDateFormat:@"YYYY年M月"];
    NSString *DateTime = [formatter stringFromDate:date];
    self.title=DateTime;

}

#pragma mark--nav添加手势
-(void)navBarTap
{
    UITapGestureRecognizer *navTapGest=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(nacTapGestClick:)];
    _gestView=[[UIView alloc]initWithFrame:CGRectMake(self.view.frame.size.width/4, 0, self.view.frame.size.width/2, 44)];
    _gestView.backgroundColor=[UIColor clearColor];
    _gestView.userInteractionEnabled=YES;
    [_gestView addGestureRecognizer:navTapGest];
    [self.navigationController.navigationBar addSubview:_gestView];
    

}

#pragma mark--头部点击事件
-(void)nacTapGestClick:(UITapGestureRecognizer *)tap
{

 
    HCGDatePickerAppearance *picker = [[HCGDatePickerAppearance alloc]initWithDatePickerMode:DatePickerYearMonthMode completeBlock:^(NSDate *date) {
       
        NSString *formatStr = @"yyyy年M月";
        NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:formatStr];
        NSString *titleStr=[dateFormatter stringFromDate:date];
        self.title=titleStr;
        
        }];
    picker.hideBlock=^(BOOL isBol){

    };
    
    [picker show];
}

@end
